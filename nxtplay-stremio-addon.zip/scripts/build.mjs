// Builds the full Netflix catalog from TMDB (Netflix = watch provider 8).
// Usage: TMDB_API_KEY=xxxx REGION=US MAX_PAGES=25 node scripts/build.mjs
import { readFile, writeFile, mkdir } from "node:fs/promises";

const KEY = process.env.TMDB_API_KEY;
const REGION = process.env.REGION || "US";
const MAX_PAGES = Number(process.env.MAX_PAGES || 25); // 20 titles per page
if (!KEY) { console.error("Set TMDB_API_KEY first."); process.exit(1); }

const api = async (path, params = {}) => {
  const url = new URL("https://api.themoviedb.org/3" + path);
  url.searchParams.set("api_key", KEY);
  for (const [k, v] of Object.entries(params)) url.searchParams.set(k, v);
  for (let tries = 0; tries < 3; tries++) {
    const r = await fetch(url);
    if (r.ok) return r.json();
    if (r.status === 404) return null;
    await new Promise(s => setTimeout(s, 1500));
  }
  return null;
};

const pool = async (items, size, fn) => {
  const out = []; let i = 0;
  await Promise.all(Array.from({ length: size }, async () => {
    while (i < items.length) { const n = i++; out[n] = await fn(items[n]); }
  }));
  return out;
};

const manifest = JSON.parse(await readFile("manifest.json", "utf8"));

for (const [tmdbType, stremioType] of [["movie", "movie"], ["tv", "series"]]) {
  const genres = Object.fromEntries(((await api(`/genre/${tmdbType}/list`))?.genres || []).map(g => [g.id, g.name]));
  const found = [];
  for (let page = 1; page <= MAX_PAGES; page++) {
    const d = await api(`/discover/${tmdbType}`, {
      with_watch_providers: 8, watch_region: REGION, with_watch_monetization_types: "flatrate",
      sort_by: "popularity.desc", page
    });
    if (!d || !d.results?.length) break;
    found.push(...d.results);
    if (page >= d.total_pages) break;
  }
  console.log(`${tmdbType}: ${found.length} titles found, resolving IMDb ids...`);

  const metas = (await pool(found, 8, async t => {
    const x = await api(`/${tmdbType}/${t.id}`, { append_to_response: "external_ids" });
    const imdb = x?.external_ids?.imdb_id || x?.imdb_id;
    if (!imdb) return null;
    const date = t.release_date || t.first_air_date || "";
    return {
      id: imdb, type: stremioType, name: t.title || t.name,
      poster: t.poster_path ? "https://image.tmdb.org/t/p/w342" + t.poster_path : `https://images.metahub.space/poster/medium/${imdb}/img`,
      background: t.backdrop_path ? "https://image.tmdb.org/t/p/w780" + t.backdrop_path : undefined,
      description: t.overview, releaseInfo: date.slice(0, 4),
      genres: (t.genre_ids || []).map(g => genres[g]).filter(Boolean)
    };
  })).filter(Boolean);

  const dir = `catalog/${stremioType}`;
  await mkdir(`${dir}/netflix`, { recursive: true });
  await writeFile(`${dir}/netflix.json`, JSON.stringify({ metas }));

  const names = [...new Set(metas.flatMap(m => m.genres))].sort();
  for (const g of names) {
    await writeFile(`${dir}/netflix/genre=${g}.json`, JSON.stringify({ metas: metas.filter(m => m.genres.includes(g)) }));
  }
  manifest.catalogs.find(c => c.type === stremioType).extra = [{ name: "genre", options: names, isRequired: false }];
  console.log(`${stremioType}: wrote ${metas.length} titles, ${names.length} genres`);
}
await writeFile("manifest.json", JSON.stringify(manifest, null, 1));
console.log("Done.");
