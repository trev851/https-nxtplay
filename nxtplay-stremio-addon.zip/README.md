# NXTPLAY – Stremio addon (Netflix catalog)

Install in Stremio: open `stremio://trev851.github.io/https-nxtplay/manifest.json`
(or paste `https://trev851.github.io/https-nxtplay/manifest.json` into the addon search box).

This is a catalog-only addon: it lists titles on the Discover/Board pages. Streams come from your other addons.

## Setup
1. Upload all files to the repo root and turn on GitHub Pages (Settings > Pages > main branch, root).
2. Get a free TMDB API key (themoviedb.org > Settings > API).
3. Repo Settings > Secrets and variables > Actions > New secret: `TMDB_API_KEY`.
4. Actions tab > "Update Netflix catalog" > Run workflow. It rebuilds the full catalog, then refreshes weekly.
   Change `REGION` (e.g. BS, US, GB) and `MAX_PAGES` (20 titles per page) in `.github/workflows/update.yml`.
