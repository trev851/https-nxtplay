# NXTPLAY – Stremio addon for Render

Live Netflix movies + TV catalog (via TMDB) with genre filters, search and scrolling.

## Deploy on Render
1. Push these files to your GitHub repo (root).
2. Render > New > Web Service > connect the repo.
   Build command: `npm install`   Start command: `npm start`
   (or New > Blueprint, which reads render.yaml)
3. Environment: add `TMDB_API_KEY` (free key from themoviedb.org > Settings > API).
   Optional: `REGION` = US, GB, CA, BS ... (Netflix's library differs per country).
4. Open your Render URL. Check `/health` says tmdbKey: true, then click Install.
   Manifest URL: https://YOUR-APP.onrender.com/manifest.json

Note: free Render services sleep after ~15 min idle, and the first request after sleeping can take ~30-60 s.
Ping /health every 10 min (e.g. UptimeRobot) or use a paid plan to keep it awake.
